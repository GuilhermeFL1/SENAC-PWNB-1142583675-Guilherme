function validar() {
    var nome = document.getElementById("nome").value;
    var senha = document.getElementById("senhaInput").value;
    var senhaConfirm = document.getElementById("senhaConfirm").value;
    var email = document.getElementById("email").value;
    var cpf = document.getElementById("cpf").value;
    
    // Custom validation rules
    var regNome = new RegExp("[A-Za-z ]{6,100}");
    var regSenha = new RegExp("^(?=.*[A-Z])(?=.*[!@#$%^&*])(?=.*[0-9])(?=.*[a-z]).{6,25}");
    var regEmail = new RegExp("^[A-Za-z0-9._%-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}");
    var regCpf = new RegExp("[0-9]{11}");
    
    
    if (!regNome.test(nome)) {
        alert("Informe um nome válido (mínimo 6 caracteres)!");
    } else if (!regSenha.test(senha)) {
        alert("Informe uma senha forte!");
    } else if (senha !== senhaConfirm) {
        alert("As senhas não coincidem!");
    } else if (!regEmail.test(email)) {
        alert("Informe um email válido!");
    } else if (!regCpf.test(cpf)) {
        alert("Informe um CPF válido (11 dígitos numéricos)!");
    } else {
        alert("Cadastro realizado com sucesso!");
        // Add code here to submit the form or perform other actions.
    }
}
