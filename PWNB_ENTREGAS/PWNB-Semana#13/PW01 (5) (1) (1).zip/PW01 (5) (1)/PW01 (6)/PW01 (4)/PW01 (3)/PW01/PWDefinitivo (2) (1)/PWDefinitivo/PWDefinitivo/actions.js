document.addEventListener("DOMContentLoaded", function() {
    var enviarBtn = document.getElementById("enviarBtn");
    var senhaInput = document.getElementById("senhaInput");
    var nomeInput = document.getElementById("nomeInput");

    enviarBtn.addEventListener("click", function() {
        validarForm();
    });

    nomeInput.addEventListener("keydown", function(event) {
        if (event.keyCode === 13) {
            senhaInput.focus();
        }
    });

    senhaInput.addEventListener("keydown", function(event) {
        if (event.keyCode === 13) {
            validarForm();
        }
    });

    function showWarning(message) {
        alert(message);
    }

    function validarForm() {
        var nome = nomeInput.value;
        var senha = senhaInput.value;

        // Custom validation rules based on your provided regular expressions
        var regNome = new RegExp("[A-z ]{6,100}");
        var regSenha = new RegExp("^(?=.*[A-Z])(?=.*[!#@$%&])(?=.*[0-9])(?=.*[a-z]).{6,25}");

        if (!regNome.test(nome)) {
            showWarning("Informe um nome completo (mínimo 6 caracteres)!");
        } else if (!regSenha.test(senha)) {
            showWarning("Informe uma senha forte!");
        } else {
            // If both fields pass validation, you can proceed with the form submission or other actions.
            showWarning("Olá " + nome + "!");
            console.log("Nome:", nome);
            console.log("Senha:", senha);
            // Replace the following line with the action you want to perform after validation.
            // window.location.href = "HTMLSeparado.html";
        
            window.location.href = "HTMLSeparado.html";
        
        }


    }
});
